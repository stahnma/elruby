#
# release date of tkextlib
#
module Tk
  Tkextlib_RELEASE_DATE = '2008-05-23'.freeze
end
