#
#   tkpalette.rb - load tk/palette.rb
#
require 'tk/palette'
