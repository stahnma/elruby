create_makefile("-test-/st/numhash")
