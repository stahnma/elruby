require 'mkmf'
create_makefile('continuation')

