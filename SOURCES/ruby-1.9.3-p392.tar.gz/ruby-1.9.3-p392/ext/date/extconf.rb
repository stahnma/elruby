require 'mkmf'
create_makefile('date_core')
